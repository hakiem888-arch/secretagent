# Momentum Radar — Freqtrade Streamlit Dashboard

Aplikasi antarmuka analitik, pemindaian sinyal, pemantauan posisi, dan manajemen risiko berbasis **Streamlit** yang terintegrasi dengan engine trading algoritmik **Freqtrade**.

Dirancang dengan arsitektur hibrida dua lapis (*Two-Tier Architecture*):
1. **Streamlit Dashboard (`streamlit_app.py` & `momentum_radar/`)**: Dapat dijalankan langsung di **Streamlit Community Cloud** sebagai lingkungan evaluasi dan uji coba awal (menggunakan evaluasi backtest OHLCV historis nyata pada `tests/testdata/` saat backend offline), maupun terhubung ke REST API Freqtrade jarak jauh.
2. **Freqtrade Persistent Backend (`freqtrade/` & `user_data/strategies/MomentumRadarStrategy.py`)**: Berjalan secara persisten di VPS atau mesin lokal menggunakan konfigurasi terpisah antara pengujian (`config_examples/config.dryrun.json`) dan produksi (`config_examples/config.live.template.json`).

---

## Fitur Utama (7 Halaman Bahasa Indonesia)

1. **Ringkasan**: Status koneksi backend (`ONLINE`/`OFFLINE`), status bot (`RUNNING`/`STOPPED`/`ERROR`), mode `DRY-RUN`/`LIVE`, saldo & ekuitas, P/L bersih hari ini dan terealisasi, floating P/L posisi terbuka, kurva ekuitas, serta peringatan risiko.
2. **Market Scanner**: Pemindaian multi-pair lengkap dengan harga terakhir, arah tren, momentum, sinyal (`LONG`, `SHORT`, `NO TRADE`), skor kualitas sinyal (0–100), *Confidence AI* (disertai catatan kalibrasi statistik), estimasi spread, rasio volume, indikator (`RSI`, `ADX`, `ATR%`), serta alasan sinyal diterima atau ditolak.
3. **Alert Center**: Riwayat alert terstandar dengan klasifikasi gaya trading nyata (`SCALPING`, `INTRADAY`, `SWING`), timeframe entry & konfirmasi, SL/TP berbasis ATR, *Risk/Reward* bersih setelah biaya, status alert (`BARU`, `DIEKSEKUSI`, `DITOLAK`, `KEDALUWARSA`, `SELESAI`), serta deduplikasi dan *cooldown* otomatis.
4. **Open Positions**: Pemantauan posisi terbuka secara terpisah dari sinyal dan riwayat transaksi, lengkap dengan ukuran posisi, P/L nominal & persentase, SL/TP, durasi, status order (`TERISI` / `MENUNGGU LIMIT`), dan indikator status risiko (`AMAN`, `WASPADA`, `KRITIS`).
5. **Trade History & Evaluasi Gaya Trading**: Riwayat transaksi tertutup bersih setelah biaya beserta tabel evaluasi khusus untuk **`SCALPING`**, **`INTRADAY`**, dan **`SWING`** (jumlah trade, gross P/L, biaya, net P/L, win rate, average win/loss, profit factor, expectancy, drawdown, dan durasi rata-rata).
6. **Strategy & Risk Settings**: Pengaturan strategi dengan validasi ketat, pratinjau ringkasan perubahan (*diff*), konfirmasi eksplisit dua langkah, proteksi berlapis untuk mode `LIVE`, serta panel kontrol darurat (*Emergency Controls*) yang membedakan `stopbuy`, `stop`, `cancel_open_order`, dan `forceexit`.
7. **System Health & Logs**: Pemeriksaan kesehatan REST API, deteksi data basi (*stale data*), riwayat latensi koneksi, serta log sistem yang telah disanitasi dari API key, password, JWT secret, dan token.

---

## Instalasi & Menjalankan Secara Lokal

### 1. Menjalankan Dashboard Streamlit (Mode Evaluasi / Monitoring)

```bash
# 1. Buat dan aktifkan virtual environment (Python 3.11 atau 3.12+)
python3 -m venv .venv
source .venv/bin/activate

# 2. Instal dependensi dashboard
pip install -r requirements.txt

# 3. Jalankan dashboard Streamlit
streamlit run streamlit_app.py
```

Dashboard akan terbuka di `http://localhost:8501`. Apabila variabel `FREQTRADE_API_URL` belum diatur (atau backend Freqtrade belum menyala), dashboard secara otomatis masuk ke **Mode Evaluasi Backtest Historis (`tests/testdata/*.feather`)** dengan label yang jelas dan tanpa crash.

### 2. Menjalankan Backend Freqtrade (Mode Dry-Run di Lokal / VPS)

```bash
# Instal dependensi penuh engine Freqtrade (membutuhkan Python >= 3.12 untuk engine penuh)
pip install -r requirements-freqtrade.txt
pip install -e .

# Salin contoh environment variable dan sesuaikan password/JWT secret
cp .env.example .env

# Jalankan bot dalam mode DRY-RUN menggunakan strategi MomentumRadarStrategy
freqtrade trade --config config_examples/config.dryrun.json --strategy MomentumRadarStrategy
```

### 3. Menjalankan Suite Pengujian Otomatis

```bash
python3 tests/momentum_radar/run_all_tests.py
```

---

## Dokumentasi Lengkap

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — Hasil audit repository awal dan arsitektur sistem dua lapis.
- [`docs/IMPLEMENTATION_PLAN.md`](docs/IMPLEMENTATION_PLAN.md) — Rincian komponen yang tersedia, diperbaiki, dan baru dibuat.
- [`docs/STREAMLIT_CLOUD_DEPLOYMENT.md`](docs/STREAMLIT_CLOUD_DEPLOYMENT.md) — Panduan deployment ke Streamlit Community Cloud, konfigurasi Secrets, dan batasan platform.
- [`docs/FREQTRADE_BACKEND_DEPLOYMENT.md`](docs/FREQTRADE_BACKEND_DEPLOYMENT.md) — Panduan deployment backend Freqtrade persisten di VPS, pengamanan HTTPS/VPN, serta langkah migrasi dari tahap evaluasi ke produksi.
