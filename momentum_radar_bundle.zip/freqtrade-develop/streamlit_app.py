"""
Entry Point Utama — Momentum Radar Streamlit Dashboard.
Dapat dijalankan secara lokal maupun di-deploy ke Streamlit Community Cloud:
    streamlit run streamlit_app.py

Fitur Utama:
- Tidak pernah memulai proses bot trading atau subprocess baru saat halaman di-render/rerun.
- Tetap dapat dibuka dengan aman ketika backend Freqtrade sedang offline, menggunakan
  evaluasi backtest OHLCV historis nyata (`tests/testdata/`) atau status kosong yang jujur.
- Default wajib DRY-RUN dan menyensor seluruh secret/token dari log maupun UI.
"""

from __future__ import annotations

from typing import Any, Literal

from momentum_radar.alerts import AlertCenterManager
from momentum_radar.api_client import MomentumRadarApiClient
from momentum_radar.config import load_connection_settings
from momentum_radar.data_provider import DashboardDataBundle, load_dashboard_bundle
from momentum_radar.models import StrategyRiskConfig
from momentum_radar.ui.pages import (
    render_alert_center_page,
    render_market_scanner_page,
    render_open_positions_page,
    render_ringkasan_page,
    render_strategy_risk_settings_page,
    render_system_health_page,
    render_trade_history_page,
)
from momentum_radar.ui.st_compat import st


PAGE_NAMES: list[str] = [
    "1. Ringkasan",
    "2. Market Scanner",
    "3. Alert Center",
    "4. Open Positions",
    "5. Trade History",
    "6. Strategy & Risk Settings",
    "7. System Health & Logs",
]


@st.cache_resource
def get_shared_api_client(server_url: str, username: str, password: str, timeout: int) -> MomentumRadarApiClient:
    """Resource bersama yang aman di-cache tanpa membuat koneksi atau thread berulang."""
    return MomentumRadarApiClient(
        server_url=server_url,
        username=username,
        password=password,
        timeout=timeout,
    )


def init_session_state() -> None:
    """Inisialisasi state antarmuka di `st.session_state` secara idempoten (aman terhadap rerun)."""
    if "active_risk_config" not in st.session_state:
        st.session_state["active_risk_config"] = StrategyRiskConfig()
    if "alert_manager" not in st.session_state:
        cfg: StrategyRiskConfig = st.session_state["active_risk_config"]
        st.session_state["alert_manager"] = AlertCenterManager(
            cooldown_minutes=cfg.cooldown_minutes,
            dedup_enabled=cfg.alert_dedup_enabled,
        )
    if "offline_fallback_mode" not in st.session_state:
        st.session_state["offline_fallback_mode"] = "HISTORICAL_BACKTEST"
    if "rerun_count" not in st.session_state:
        st.session_state["rerun_count"] = 0
    st.session_state["rerun_count"] += 1


def run_dashboard_app(selected_page_override: str | None = None) -> DashboardDataBundle:
    """
    Menjalankan alur utama aplikasi Streamlit Momentum Radar.
    Mengembalikan `DashboardDataBundle` untuk mempermudah pengujian otomatis (smoke test).
    """
    st.set_page_config(
        page_title="Momentum Radar — Freqtrade Dashboard",
        page_icon="📡",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    init_session_state()

    raw_secrets: dict[str, Any] = {}
    try:
        if hasattr(st, "secrets") and st.secrets:
            raw_secrets = dict(st.secrets)
    except Exception:
        raw_secrets = {}

    conn_settings = load_connection_settings(raw_secrets)
    risk_config: StrategyRiskConfig = st.session_state["active_risk_config"]
    alert_manager: AlertCenterManager = st.session_state["alert_manager"]
    alert_manager.cooldown_minutes = risk_config.cooldown_minutes
    alert_manager.dedup_enabled = risk_config.alert_dedup_enabled

    # Navigasi Sidebar
    with st.sidebar:
        st.title("📡 Momentum Radar")
        st.caption("Dashboard Evaluasi Sinyal, Posisi & Risiko Freqtrade")

        selected_page = st.radio(
            "Navigasi Halaman",
            options=PAGE_NAMES,
            index=0,
            key="nav_selected_page",
        )
        if selected_page_override in PAGE_NAMES:
            selected_page = selected_page_override

        st.divider()
        st.subheader("Koneksi & Mode Evaluasi")
        custom_api_url = st.text_input(
            "URL Freqtrade REST API (Opsional)",
            value=conn_settings["api_url"],
            key="sidebar_api_url",
        )
        offline_choice = st.selectbox(
            "Perilaku Saat Backend Offline",
            options=[
                "Evaluasi Backtest Historis (tests/testdata)",
                "Tampilkan Status Kosong (Tanpa Data)",
            ],
            index=0 if st.session_state.get("offline_fallback_mode") == "HISTORICAL_BACKTEST" else 1,
            key="sidebar_offline_mode",
        )
        preferred_offline: Literal["HISTORICAL_BACKTEST", "EMPTY"] = (
            "HISTORICAL_BACKTEST"
            if "Historis" in str(offline_choice)
            else "EMPTY"
        )
        st.session_state["offline_fallback_mode"] = preferred_offline

        st.caption(
            f"Mode Aktif: **{risk_config.trading_mode}** | "
            f"Timeframe: **{risk_config.timeframe}** | "
            f"Siklus Render: **#{st.session_state['rerun_count']}**"
        )

    api_client = get_shared_api_client(
        server_url=custom_api_url.strip(),
        username=conn_settings["username"],
        password=conn_settings["password"],
        timeout=conn_settings["timeout_seconds"],
    )

    bundle = load_dashboard_bundle(
        api_client=api_client,
        risk_config=risk_config,
        alert_manager=alert_manager,
        preferred_offline_mode=preferred_offline,
        stale_threshold_seconds=conn_settings["stale_threshold_seconds"],
    )

    if selected_page == "1. Ringkasan":
        render_ringkasan_page(bundle)
    elif selected_page == "2. Market Scanner":
        render_market_scanner_page(bundle, risk_config)
    elif selected_page == "3. Alert Center":
        render_alert_center_page(bundle, risk_config)
    elif selected_page == "4. Open Positions":
        render_open_positions_page(bundle)
    elif selected_page == "5. Trade History":
        render_trade_history_page(bundle)
    elif selected_page == "6. Strategy & Risk Settings":
        render_strategy_risk_settings_page(bundle, risk_config, api_client)
    elif selected_page == "7. System Health & Logs":
        render_system_health_page(bundle)

    return bundle


if __name__ == "__main__":
    run_dashboard_app()
