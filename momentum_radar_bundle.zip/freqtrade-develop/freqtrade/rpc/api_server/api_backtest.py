import asyncio
import logging
from copy import deepcopy
from io import StringIO
from pathlib import Path
from typing import Any

from fastapi import APIRouter, BackgroundTasks, Depends
from fastapi.exceptions import HTTPException

from freqtrade.configuration import remove_exchange_credentials
from freqtrade.configuration.config_validation import validate_config_consistency
from freqtrade.constants import Config
from freqtrade.data.btanalysis import (
    backtest_strategy_dir,
    delete_backtest_result,
    get_backtest_market_change,
    get_backtest_result,
    get_backtest_resultlist,
    get_backtest_wallet_change,
    load_and_merge_backtest_result,
    load_file_from_zip,
    update_backtest_metadata,
)
from freqtrade.enums import BacktestState, RunMode
from freqtrade.exceptions import ConfigurationError, DependencyException, OperationalException
from freqtrade.ft_types import get_BacktestResultType_default
from freqtrade.misc import deep_merge_dicts, is_file_in_dir, json_load
from freqtrade.rpc.api_server.api_pairlists import handleExchangePayload
from freqtrade.rpc.api_server.api_schemas import (
    BacktestHistoryEntry,
    BacktestMarketChange,
    BacktestMetadataUpdate,
    BacktestPairHistoryRequest,
    BacktestRequest,
    BacktestResponse,
    ExchangeModePayloadMixin,
    PairHistory,
    StrategyName,
    WalletHistoryResponse,
)
from freqtrade.rpc.api_server.deps import get_config, get_exchange
from freqtrade.rpc.api_server.webserver_bgwork import ApiBG
from freqtrade.rpc.rpc import RPC, RPCException
from freqtrade.util import dt_now


logger = logging.getLogger(__name__)

# Private API, protected by authentication and webserver_mode dependency
router = APIRouter()


def __run_backtest_bg(
    btconfig: Config, job_id: str, strategy_params: list[dict[str, Any]] | None = None
):
    from freqtrade.data.metrics import combined_dataframes_with_rel_mean
    from freqtrade.optimize.optimize_reports import generate_backtest_stats, store_backtest_results
    from freqtrade.resolvers import StrategyResolver

    job = ApiBG.jobs[job_id]
    job["is_running"] = True
    asyncio.set_event_loop(asyncio.new_event_loop())
    try:
        # Reload strategy
        lastconfig = ApiBG.bt["last_config"]
        strat = StrategyResolver.load_strategy(btconfig)
        strat.ft_set_api_params(strategy_params)
        validate_config_consistency(btconfig)
        time_settings_changed = (
            lastconfig.get("timeframe") != strat.timeframe
            or lastconfig.get("timeframe_detail") != btconfig.get("timeframe_detail")
            or lastconfig.get("timerange") != btconfig["timerange"]
        )
        from freqtrade.optimize.backtesting import Backtesting

        def ft_callback(task) -> None:
            job["progress_tasks"][str(task.id)] = {
                "progress": task.completed,
                "total": task.total,
                "description": task.description,
            }

        if not ApiBG.bt["bt"] or time_settings_changed:
            job["progress_tasks"] = {}
            ApiBG.bt["bt"] = Backtesting(btconfig, progress_callback=ft_callback)
            if not ApiBG.bt["bt"]:
                raise DependencyException("Backtesting instance not initialized.")
        else:
            ApiBG.bt["bt"]._progress_callback = ft_callback
            ApiBG.bt["bt"].config = deep_merge_dicts(btconfig, ApiBG.bt["bt"].config)
            ApiBG.bt["bt"].init_backtest()
        cachedBt: Backtesting = ApiBG.bt["bt"]
        # Only reload data if timerange is open or settings changed
        if not ApiBG.bt["data"] or not ApiBG.bt["timerange"] or time_settings_changed:
            ApiBG.bt["data"], ApiBG.bt["timerange"] = cachedBt.load_bt_data()
            if not ApiBG.bt["data"] or not ApiBG.bt["timerange"]:
                raise DependencyException("Backtesting data not loaded.")

        lastconfig["timerange"] = btconfig["timerange"]
        lastconfig["timeframe_detail"] = btconfig.get("timeframe_detail")
        lastconfig["timeframe"] = strat.timeframe
        lastconfig["enable_protections"] = btconfig.get("enable_protections")
        lastconfig["dry_run_wallet"] = btconfig.get("dry_run_wallet")

        cachedBt.enable_protections = btconfig.get("enable_protections", False)
        cachedBt.strategylist = [strat]
        cachedBt.results = get_BacktestResultType_default()
        cachedBt.load_prior_backtest()

        cachedBt.abort = False
        strategy_name = strat.get_strategy_name()
        if cachedBt.results and strategy_name in cachedBt.results["strategy"]:
            # When previous result hash matches - reuse that result and skip backtesting.
            logger.info(f"Reusing result of previous backtest for {strategy_name}")
        else:
            min_date, max_date = cachedBt.backtest_one_strategy(
                strat, ApiBG.bt["data"], ApiBG.bt["timerange"]
            )

            cachedBt.results = generate_backtest_stats(
                ApiBG.bt["data"],
                cachedBt.all_bt_content,
                min_date=min_date,
                max_date=max_date,
            )

            if btconfig.get("export", "none") == "trades":
                combined_res = combined_dataframes_with_rel_mean(
                    ApiBG.bt["data"], min_date, max_date
                )
                fn = store_backtest_results(
                    btconfig,
                    cachedBt.results,
                    dt_now().strftime("%Y-%m-%d_%H-%M-%S"),
                    market_change_data=combined_res,
                    wallet_summary={
                        s: x["wallet_summary"]
                        for s, x in cachedBt.all_bt_content.items()
                        if "wallet_summary" in x
                    },
                    strategy_files={
                        s.get_strategy_name(): s.__file__ for s in cachedBt.strategylist
                    },
                    # Store the used parameters if the API provided overrides
                    strategy_params=(
                        {strategy_name: strat.ft_used_params} if strategy_params else None
                    ),
                )
                cachedBt.results["metadata"][strategy_name]["filename"] = str(fn.stem)
                cachedBt.results["metadata"][strategy_name]["strategy"] = strategy_name
        cachedBt.reset_backtest()
        job["status"] = "success"
        logger.info("Backtest finished.")

    except ConfigurationError as e:
        logger.error(f"Backtesting encountered a configuration Error: {e}")
        job["status"] = "failed"
        job["error"] = str(e)

    except (Exception, OperationalException, DependencyException) as e:
        logger.exception(f"Backtesting caused an error: {e}")
        job["status"] = "failed"
        job["error"] = str(e)
    finally:
        job["is_running"] = False
        ApiBG.analysis_running = False


@router.post("/backtest", response_model=BacktestResponse)
async def api_start_backtest(
    bt_settings: BacktestRequest, background_tasks: BackgroundTasks, config=Depends(get_config)
):
    """Start backtesting if not done so already"""
    if ApiBG.analysis_running:
        raise RPCException("Bot Background task already running")

    btconfig = deepcopy(config)
    btconfig["runmode"] = RunMode.BACKTEST
    remove_exchange_credentials(btconfig["exchange"], True)
    settings = bt_settings.model_dump(mode="python")
    strategy_params: list[dict[str, Any]] | None = settings.pop("strategy_params", None)
    # Pydantic models will contain all keys, but non-provided ones are None

    btconfig = deep_merge_dicts(settings, btconfig, allow_null_overrides=False)
    try:
        btconfig["stake_amount"] = float(btconfig["stake_amount"])
    except ValueError:
        pass

    # Force dry-run for backtesting
    btconfig["dry_run"] = True

    # Start backtesting
    # Initialize backtesting object
    job_id = ApiBG.get_job_id()
    ApiBG.jobs[job_id] = {
        "category": "backtest",
        "status": "pending",
        "progress": None,
        "progress_tasks": {},
        "is_running": False,
        "result": {},
        "error": None,
    }
    ApiBG.bt["job_id"] = job_id

    background_tasks.add_task(
        __run_backtest_bg, btconfig=btconfig, job_id=job_id, strategy_params=strategy_params
    )
    ApiBG.analysis_running = True

    return {
        "status": "running",
        "running": True,
        "progress": 0,
        "step": str(BacktestState.STARTUP),
        "status_msg": "Backtest started",
    }


@router.get("/backtest", response_model=BacktestResponse)
def api_get_backtest():
    """
    Get backtesting result.
    Returns Result after backtesting has been ran.
    """
    from freqtrade.persistence import LocalTrade

    job = ApiBG.jobs.get(ApiBG.bt.get("job_id") or "")

    if ApiBG.analysis_running:
        bt = ApiBG.bt["bt"]
        progress_tasks = (job.get("progress_tasks") if job else None) or {}
        # Derive the legacy step/progress fields from the inner/detail task, preserving
        # the previous per-phase semantics.
        detail = progress_tasks.get(str(bt._progress_task), {}) if bt else {}
        detail_total = detail.get("total") or 0
        return {
            "status": "running",
            "running": True,
            "step": detail.get("description", str(BacktestState.STARTUP)),
            "progress": (
                max(min(detail.get("progress", 0) / detail_total, 1), 0) if detail_total else 0
            ),
            "trade_count": len(LocalTrade.bt_trades),
            "status_msg": "Backtest running",
        }

    if not ApiBG.bt["bt"]:
        return {
            "status": "not_started",
            "running": False,
            "step": "",
            "progress": 0,
            "status_msg": "Backtest not yet executed",
        }
    if job and job["error"]:
        return {
            "status": "error",
            "running": False,
            "step": "",
            "progress": 0,
            "status_msg": f"Backtest failed with {job['error']}",
        }

    return {
        "status": "ended",
        "running": False,
        "status_msg": "Backtest ended",
        "step": "finished",
        "progress": 1,
        "backtest_result": ApiBG.bt["bt"].results,
    }


@router.delete("/backtest", response_model=BacktestResponse)
def api_delete_backtest():
    """Reset backtesting"""
    if ApiBG.analysis_running:
        return {
            "status": "running",
            "running": True,
            "step": "",
            "progress": 0,
            "status_msg": "Backtest running",
        }
    if ApiBG.bt["bt"]:
        ApiBG.bt["bt"].cleanup()
        del ApiBG.bt["bt"]
        ApiBG.bt["bt"] = None
        del ApiBG.bt["data"]
        ApiBG.bt["data"] = None
        ApiBG.bt["job_id"] = None
        logger.info("Backtesting reset")
    return {
        "status": "reset",
        "running": False,
        "step": "",
        "progress": 0,
        "status_msg": "Backtest reset",
    }


@router.get("/backtest/abort", response_model=BacktestResponse)
def api_backtest_abort():
    if not ApiBG.analysis_running:
        return {
            "status": "not_running",
            "running": False,
            "step": "",
            "progress": 0,
            "status_msg": "Backtest ended",
        }
    ApiBG.bt["bt"].abort = True
    return {
        "status": "stopping",
        "running": False,
        "step": "",
        "progress": 0,
        "status_msg": "Backtest ended",
    }


@router.get("/backtest/history", response_model=list[BacktestHistoryEntry])
def api_backtest_history(config=Depends(get_config)):
    # Get backtest result history, read from metadata files
    return get_backtest_resultlist(config["user_data_dir"] / "backtest_results")


@router.get("/backtest/history/result", response_model=BacktestResponse)
def api_backtest_history_result(filename: str, strategy: StrategyName, config=Depends(get_config)):
    # Get backtest result history, read from metadata files
    bt_results_base: Path = config["user_data_dir"] / "backtest_results"
    for ext in [".zip", ".json"]:
        fn = (bt_results_base / filename).with_suffix(ext)
        if is_file_in_dir(fn, bt_results_base):
            break
    else:
        raise HTTPException(status_code=404, detail="File not found.")

    results: dict[str, Any] = {
        "metadata": {},
        "strategy": {},
        "strategy_comparison": [],
    }
    load_and_merge_backtest_result(strategy, fn, results)
    return {
        "status": "ended",
        "running": False,
        "step": "",
        "progress": 1,
        "status_msg": "Historic result",
        "backtest_result": results,
    }


@router.delete("/backtest/history/{file}", response_model=list[BacktestHistoryEntry])
def api_delete_backtest_history_entry(file: str, config=Depends(get_config)):
    # Get backtest result history, read from metadata files
    bt_results_base: Path = config["user_data_dir"] / "backtest_results"
    for ext in [".zip", ".json"]:
        file_abs = (bt_results_base / file).with_suffix(ext)
        # Ensure file is in backtest_results directory
        if is_file_in_dir(file_abs, bt_results_base):
            break
    else:
        raise HTTPException(status_code=404, detail="File not found.")

    delete_backtest_result(file_abs)
    return get_backtest_resultlist(config["user_data_dir"] / "backtest_results")


@router.patch("/backtest/history/{file}", response_model=list[BacktestHistoryEntry])
def api_update_backtest_history_entry(
    file: str, body: BacktestMetadataUpdate, config=Depends(get_config)
):
    # Get backtest result history, read from metadata files
    bt_results_base: Path = config["user_data_dir"] / "backtest_results"
    for ext in [".zip", ".json"]:
        file_abs = (bt_results_base / file).with_suffix(ext)
        # Ensure file is in backtest_results directory
        if is_file_in_dir(file_abs, bt_results_base):
            break
    else:
        raise HTTPException(status_code=404, detail="File not found.")

    content = {"notes": body.notes}
    try:
        update_backtest_metadata(file_abs, body.strategy, content)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return get_backtest_result(file_abs)


@router.get("/backtest/history/{file}/market_change", response_model=BacktestMarketChange)
def api_get_backtest_market_change(file: str, config=Depends(get_config)):
    bt_results_base: Path = config["user_data_dir"] / "backtest_results"
    for fn in (
        Path(file).with_suffix(".zip"),
        Path(f"{file}_market_change").with_suffix(".feather"),
    ):
        file_abs = bt_results_base / fn
        # Ensure file is in backtest_results directory
        if is_file_in_dir(file_abs, bt_results_base):
            break
    else:
        raise HTTPException(status_code=404, detail="File not found.")

    df = get_backtest_market_change(file_abs)

    return {
        "columns": df.columns.tolist(),
        "data": df.values.tolist(),
        "length": len(df),
    }


@router.get(
    "/backtest/history/{file}/{strategy}/wallet",
    response_model=WalletHistoryResponse,
    tags=["webserver", "backtest"],
)
def api_get_backtest_wallet(file: str, strategy: StrategyName, config=Depends(get_config)):
    bt_results_base: Path = config["user_data_dir"] / "backtest_results"
    file_abs = (bt_results_base / file).with_suffix(".zip")
    # Ensure file is in backtest_results directory
    if not is_file_in_dir(file_abs, bt_results_base):
        raise HTTPException(status_code=400, detail="Unable to retrieve wallet history.")

    results = get_backtest_wallet_change(file_abs, strategy)
    if results is None:
        raise HTTPException(status_code=404, detail="Unable to retrieve wallet history.")
    # Consolidate the wallet to the base currency
    results.loc[:, "total_quote"] = results["rate"] * results["balance"]
    results = results.groupby(["date", "__date_ts"]).agg({"total_quote": "sum"}).reset_index()

    return {
        "columns": results.columns.tolist(),
        "data": results.values.tolist(),
        "length": len(results),
    }


@router.post(
    "/backtest/history/{file}/{strategy}/pair_history",
    response_model=PairHistory,
    tags=["webserver", "backtest"],
)
def api_backtest_pair_history(
    file: str,
    strategy: StrategyName,
    payload: BacktestPairHistoryRequest,
    config=Depends(get_config),
):
    """
    Analyze a pair with the strategy and parameters stored in a backtest result.
    Contrary to /pair_history, this uses the strategy as it was at the time of the backtest,
    instead of the current version in the strategy directory.
    """
    bt_results_base: Path = config["user_data_dir"] / "backtest_results"
    file_abs = (bt_results_base / file).with_suffix(".zip")
    # Ensure file is in backtest_results directory
    if not is_file_in_dir(file_abs, bt_results_base):
        raise HTTPException(status_code=404, detail="File not found.")

    bt_result = next((r for r in get_backtest_result(file_abs) if r["strategy"] == strategy), None)
    if bt_result is None:
        raise HTTPException(status_code=404, detail=f"Strategy {strategy} not found in {file}.")

    # Older results may not have these stored in their metadata.
    if not (timeframe := bt_result["timeframe"]):
        raise HTTPException(
            status_code=422, detail=f"Backtest result {file} does not contain a timeframe."
        )
    timerange = payload.timerange
    if not timerange:
        # backtest_start_ts are in the backtest output files since 2 years.
        timerange = f"{bt_result['backtest_start_ts']}-{bt_result['backtest_end_ts']}"

    config_loc = deepcopy(config)
    config_loc.update({"strategy": strategy, "timeframe": timeframe, "timerange": timerange})

    try:
        # Exchange settings of the backtest may differ from the current webserver config.
        bt_config = json_load(
            StringIO(load_file_from_zip(file_abs, f"{file_abs.stem}_config.json").decode("utf-8"))
        )
        handleExchangePayload(
            ExchangeModePayloadMixin(
                exchange=bt_config.get("exchange", {}).get("name"),
                trading_mode=bt_config.get("trading_mode", "spot"),
                margin_mode=bt_config.get("margin_mode"),
            ),
            config_loc,
        )
        # The strategy is imported lazily, so the directory must exist for the whole call.
        with backtest_strategy_dir(file_abs, strategy) as strategy_dir:
            config_loc["strategy_path"] = str(strategy_dir)
            exchange = get_exchange(config_loc)
            validate_config_consistency(config_loc)

            return RPC._rpc_analysed_history_full(
                config_loc, payload.pair, timeframe, exchange, payload.columns, False
            )
    except ConfigurationError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except ValueError as e:
        # Older results may not contain the config or the strategy.
        raise HTTPException(
            status_code=422, detail=f"Backtest result {file} cannot be replayed: {e}"
        )
    except Exception as e:
        logger.exception("Error in api_backtest_pair_history")
        raise HTTPException(status_code=502, detail=str(e))
