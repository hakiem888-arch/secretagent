# Panduan Deployment Backend Freqtrade di VPS & Migrasi dari Tahap Evaluasi

Dokumen ini menjelaskan cara menjalankan **Freqtrade Backend** secara persisten di VPS (Ubuntu/Debian), mengamankan endpoint REST API, memisahkan lingkungan `DRY-RUN` dari `LIVE`, serta langkah migrasi setelah evaluasi di Streamlit Community Cloud selesai.

---

## 1. Persiapan Server VPS & Keamanan Dasar

1. Gunakan VPS Linux (disarankan Ubuntu 22.04 / 24.04 LTS, minimal 2 vCPU dan 2–4 GB RAM).
2. Aktifkan firewall `ufw` dan **jangan pernah mengekspos port `8080` Freqtrade secara langsung ke internet publik tanpa TLS/HTTPS**:
   ```bash
   sudo ufw default deny incoming
   sudo ufw default allow outgoing
   sudo ufw allow ssh
   sudo ufw allow 443/tcp
   sudo ufw enable
   ```
3. Pastikan `listen_ip_address` di `config.dryrun.json` dan `config.live.template.json` tetap dikunci ke `127.0.0.1` (atau IP interface Docker internal), lalu gunakan **Caddy** atau **Nginx** dengan sertifikat TLS (Let's Encrypt) sebagai Reverse Proxy HTTPS di depan `127.0.0.1:8080`.

---

## 2. Pemisahan Konfigurasi & Database (`DRY-RUN` vs `LIVE`)

Repository ini menyediakan dua file konfigurasi yang terpisah secara fisik maupun database:

| Lingkungan | File Konfigurasi | Database Persistensi | Mode Eksekusi |
| :--- | :--- | :--- | :--- |
| **Pengujian / Simulasi** | `config_examples/config.dryrun.json` | `sqlite:///user_data/tradesv3.dryrun.sqlite` | `dry_run: true` |
| **Produksi (VPS)** | `config_examples/config.live.template.json` | `sqlite:///user_data/tradesv3.live.sqlite` | `dry_run: false` (Hanya setelah lulus checklist) |

Seluruh kredensial sensitif disuntikkan melalui variabel lingkungan (`.env` di VPS, bukan ditulis di dalam file JSON):
```bash
export FREQTRADE__EXCHANGE__KEY="API_KEY_BURSA_TANPA_IZIN_WITHDRAWAL"
export FREQTRADE__EXCHANGE__SECRET="API_SECRET_BURSA"
export FREQTRADE__API_SERVER__JWT_SECRET_KEY="$(openssl rand -hex 32)"
export FREQTRADE__API_SERVER__PASSWORD="PASSWORD_OPERATOR_MIN_24_KARAKTER"
```

---

## 3. Menjalankan Backend Menggunakan Docker Compose di VPS

Buat file `docker-compose.vps.yml` (atau gunakan `docker-compose.yml` yang tersedia) dengan menyertakan file `.env`:

```yaml
services:
  freqtrade-dryrun:
    image: freqtradeorg/freqtrade:stable
    container_name: momentum_radar_dryrun
    restart: unless-stopped
    env_file:
      - .env
    volumes:
      - "./user_data:/freqtrade/user_data"
      - "./config_examples:/freqtrade/config_examples:ro"
    ports:
      - "127.0.0.1:8080:8080"
    command: >
      trade
      --logfile /freqtrade/user_data/logs/freqtrade_dryrun.log
      --db-url sqlite:////freqtrade/user_data/tradesv3.dryrun.sqlite
      --config /freqtrade/config_examples/config.dryrun.json
      --strategy MomentumRadarStrategy
```

Jalankan dengan perintah:
```bash
docker compose -f docker-compose.vps.yml up -d
```

---

## 4. Health Check & Troubleshooting

1. **Pemeriksaan Kesehatan Lokal di VPS**:
   ```bash
   curl -s http://127.0.0.1:8080/api/v1/ping
   # Respons sehat: {"status":"pong"}
   ```
2. **Troubleshooting Koneksi dari Streamlit Cloud**:
   - **Status `OFFLINE` di Dashboard**: Periksa apakah URL pada `FREQTRADE_API_URL` menggunakan `https://` yang valid dan reverse proxy VPS meneruskan header `Authorization` ke `127.0.0.1:8080`.
   - **Error `401 Unauthorized`**: Pastikan `FREQTRADE_API_USERNAME` dan `FREQTRADE_API_PASSWORD` di Streamlit Secrets sama persis dengan `api_server.username` dan `FREQTRADE__API_SERVER__PASSWORD` di VPS.
   - **Indikator Data Basi (`Stale Data`)**: Periksa log container (`docker logs momentum_radar_dryrun`) untuk memastikan bursa tidak memblokir IP VPS atau mengalami pembatasan *rate limit*.

---

## 5. Langkah Migrasi dari Evaluasi Streamlit Cloud ke VPS Persisten

Setelah pengujian di Streamlit Community Cloud selesai dan metrik `MomentumRadarStrategy` terverifikasi:
1. Salin folder `user_data/strategies/MomentumRadarStrategy.py` dan `config_examples/config.dryrun.json` ke VPS.
2. Jalankan bot di VPS dalam mode **`DRY-RUN` selama minimal 7–14 hari kalender** untuk memverifikasi sinkronisasi order book, *slippage* nyata, dan stabilitas koneksi REST API.
3. Hubungkan dashboard Streamlit (baik di Streamlit Cloud maupun di-host sendiri di VPS) ke endpoint HTTPS VPS Anda.
4. Hanya setelah seluruh daftar periksa keamanan terpenuhi, buat salinan `config.live.json` dari `config_examples/config.live.template.json` di VPS.
