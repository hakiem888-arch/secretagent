# Panduan Deployment ke Streamlit Community Cloud (Tahap Evaluasi & Uji Coba)

Dokumen ini menjelaskan langkah-langkah men-deploy **Momentum Radar Dashboard** ke **Streamlit Community Cloud** sebagai lingkungan evaluasi awal sebelum bot dijalankan secara persisten di VPS.

---

## 1. Peran & Keterbatasan Streamlit Community Cloud

Sesuai arsitektur yang dirancang, Streamlit Community Cloud digunakan untuk:
- Mengevaluasi kualitas sinyal `MomentumRadarStrategy` pada berbagai pair dan timeframe.
- Menguji ketahanan aturan entry, exit, deduplikasi alert, serta rasio *Risk/Reward* bersih setelah biaya pada data OHLCV historis (`tests/testdata/`).
- Memantau bot Freqtrade dari jarak jauh apabila Anda menyalakan backend pengujian di komputer lokal (melalui tunnel aman seperti Cloudflare Tunnel / Tailscale Funnel) atau server VPS pengujian.

**Keterbatasan Penting Streamlit Community Cloud:**
1. **Tidak Mendukung Proses Background Persisten**: Container Streamlit Cloud akan masuk ke mode tidur (*sleep*) apabila tidak ada kunjungan pengguna selama beberapa waktu, sehingga **tidak boleh** digunakan untuk menjalankan proses loop trading Freqtrade secara langsung.
2. **Penyimpanan Lokal Bersifat Sementara (*Ephemeral*)**: File SQLite lokal di dalam container Streamlit Cloud akan terhapus setiap kali aplikasi di-*reboot* atau *redeploy*. Seluruh penyimpanan transaksi persisten harus berada di backend VPS.
3. **Buka Koneksi ke `localhost` Bukan Berarti Komputer Anda**: Di Streamlit Cloud, `127.0.0.1` atau `localhost` merujuk pada container cloud itu sendiri, bukan laptop atau VPS Anda.

---

## 2. Langkah-Langkah Deployment ke Streamlit Community Cloud

1. **Unggah Repository ke GitHub**:
   - Pastikan file `.env`, `.streamlit/secrets.toml`, dan file database `*.sqlite` **tidak** ikut ter-commit (sudah dilindungi oleh `.gitignore`).
   - Pastikan file berikut berada di root repository:
     - `streamlit_app.py`
     - `requirements.txt`
     - `.streamlit/config.toml`
2. **Buat Aplikasi Baru di Streamlit Community Cloud**:
   - Masuk ke [share.streamlit.io](https://share.streamlit.io) menggunakan akun GitHub Anda.
   - Klik **Create app** -> pilih repository GitHub Anda, branch utama (`main` atau `develop`), dan isi **Main file path** dengan:
     ```text
     streamlit_app.py
     ```
   - Klik **Advanced settings...** -> pilih versi Python **3.11** atau **3.12**.
3. **Konfigurasi Streamlit Secrets (`App Settings -> Secrets`)**:
   - Untuk **Evaluasi Tanpa Backend Aktif (Mode Backtest Historis)**, masukkan konfigurasi berikut pada kotak **Secrets**:
     ```toml
     FREQTRADE_API_URL = ""
     FREQTRADE_API_USERNAME = "momentum_operator"
     FREQTRADE_API_PASSWORD = ""
     FREQTRADE_API_TIMEOUT = 6
     DATA_STALE_THRESHOLD_SECONDS = 300
     TRADING_MODE = "DRY-RUN"
     ```
   - Apabila Anda sudah memiliki **Backend Pengujian Dry-Run** yang dapat diakses melalui HTTPS aman:
     ```toml
     FREQTRADE_API_URL = "https://freqtrade-test.domain-anda.com"
     FREQTRADE_API_USERNAME = "momentum_operator"
     FREQTRADE_API_PASSWORD = "PASSWORD_API_KUAT_ANDA"
     FREQTRADE_API_TIMEOUT = 6
     DATA_STALE_THRESHOLD_SECONDS = 300
     TRADING_MODE = "DRY-RUN"
     ```
4. **Klik Deploy**:
   - Streamlit Cloud akan menginstal paket dari `requirements.txt` (tanpa memerlukan kompilasi C `ta-lib` yang rawan gagal) dan langsung menampilkan ke-7 halaman dashboard.

---

## 3. Alternatif Menghubungkan Backend Pengujian Lokal ke Streamlit Cloud

Jika Anda ingin menguji mode `DRY-RUN` secara *real-time* tanpa menyewa VPS terlebih dahulu:
1. Jalankan Freqtrade `dry-run` di komputer lokal Anda:
   ```bash
   freqtrade trade --config config_examples/config.dryrun.json --strategy MomentumRadarStrategy
   ```
2. Ekspos port `127.0.0.1:8080` menggunakan **Cloudflare Tunnel (`cloudflared`)** dengan Access Policy atau **Tailscale Funnel** ber-HTTPS.
3. Masukkan URL HTTPS tunnel tersebut ke dalam `FREQTRADE_API_URL` di Streamlit Secrets.
