# Arsitektur Sistem — Momentum Radar & Freqtrade Streamlit Dashboard

## 1. Hasil Audit Repository Awal (`freqtrade-develop.zip`)

Berdasarkan pemeriksaan menyeluruh terhadap isi repository `freqtrade-develop.zip` (commit `7ff17f5f5ac2f7bbc55a2937fd493a68c9951647`), kondisi awal repository adalah kode sumber **Freqtrade upstream (`develop` branch)** dengan rincian faktual sebagai berikut:

### A. Komponen yang Sudah Tersedia
1. **Core Engine Freqtrade (`freqtrade/`)**:
   - Mesin eksekusi bot trading (`freqtradebot.py`, `main.py`, `worker.py`), manajemen posisi dan order, `PairLocks`, serta proteksi risiko.
   - Server REST API & WebSocket berbasis FastAPI (`freqtrade/rpc/api_server/api_v1.py`, `api_trading.py`, `api_backtest.py`, `webserver.py`).
   - Lapisan persistensi SQLAlchemy/SQLite (`freqtrade/persistence/trade_model.py`, `models.py`, `pairlock.py`).
   - Modul pembelajaran mesin FreqAI (`freqtrade/freqai/`).
   - Modul notifikasi RPC (`freqtrade/rpc/telegram.py`, `discord.py`, `webhook.py`).
2. **REST & WebSocket Client Mandiri (`ft_client/` & `scripts/`)**:
   - `ft_client/freqtrade_client/ft_rest_client.py` menyediakan class `FtRestClient` untuk komunikasi HTTP ke endpoint `/api/v1/*` Freqtrade.
   - `scripts/rest_client.py` dan `scripts/ws_client.py` untuk akses baris perintah.
3. **Strategi & Template Konfigurasi (`freqtrade/templates/` & `config_examples/`)**:
   - `SampleStrategy` (`freqtrade/templates/sample_strategy.py`), `FreqaiExampleStrategy`, dan `FreqaiExampleHybridStrategy`.
   - Contoh konfigurasi `config_binance.example.json`, `config_full.example.json`, `config_freqai.example.json`, dan `config_kraken.example.json`.
4. **Dataset Historis OHLCV & Hasil Backtest (`tests/testdata/`)**:
   - File candle `.feather` nyata (`BTC_USDT-5m.feather`, `XRP_USDT-5m.feather`, `ETH_BTC-5m.feather`, `ADA_BTC-5m.feather`, `LTC_BTC-5m.feather`, `DASH_BTC-5m.feather`, `XMR_BTC-5m.feather`, `ZEC_BTC-5m.feather`, serta data futures `XRP_USDT_USDT-5m-futures.feather` dan `1h`).
   - Hasil backtest referensi `tests/testdata/backtest_results/backtest-result.json` (179 transaksi historis).

### B. Temuan Masalah, Celah Keamanan, dan Ketidaksesuaian dengan Streamlit Community Cloud
1. **Belum Tersedia Entry Point Streamlit & Modul Momentum Radar**:
   - Repository belum memiliki `streamlit_app.py`, konfigurasi `.streamlit/config.toml`, maupun paket `momentum_radar/` untuk memisahkan UI dari engine trading.
   - Direktori `user_data/strategies/` belum dibuat.
2. **Ketergantungan yang Tidak Kompatibel dengan Streamlit Community Cloud (`requirements.txt`)**:
   - File `requirements.txt` asli mematok `ta-lib==0.8.1` (membutuhkan kompilasi C `libta-lib` yang sering gagal di Streamlit Cloud tanpa konfigurasi khusus) serta versi paket yang tidak standar/ekstrem (`numpy==2.5.4`, `pandas==3.0.6`, `cryptography==50.0.2`, `fastapi==0.143.0`, `websockets==17.2`), dan belum mencantumkan `streamlit`.
   - Terdapat file binary wheel ARMv7l berukuran ~28,5 MB di `build_helpers/` (`pyarrow-26.0.0-cp313-cp313-linux_armv7l.whl` dan `ta_lib-0.8.1-cp313-cp313-manylinux_2_31_armv7l.whl`).
3. **Bug dan Kelemahan pada `FtRestClient` (`ft_client/freqtrade_client/ft_rest_client.py`)**:
   - `HTTPAdapter` hanya dipasang pada skema `http://` (`self._session.mount("http://", adapter)`), belum mendukung `https://` untuk koneksi aman ke VPS.
   - Method `_call()` hanya menangkap `RequestConnectionError` (mengembalikan `None`), tetapi tidak menangkap `requests.exceptions.Timeout`, `HTTPError`, `SSLError`, atau `JSONDecodeError`.
   - Method `ping()` mengakses `configstatus["state"]` tanpa memeriksa apakah key `"state"` ada pada dictionary respons (menyebabkan `KeyError` saat kredensial salah atau API mengembalikan pesan error).
4. **Kredensial Placeholder Lemah & Konfigurasi Belum Terpisah**:
   - `config_examples/config_binance.example.json` dan `config_full.example.json` memuat `jwt_secret_key: "somethingRandomSomethingRandom123"` dan `password: "SuperSecurePassword"`.
   - Belum ada pemisahan tegas antara konfigurasi pengujian (`config.dryrun.json`) dan template produksi (`config.live.template.json`).
5. **Kelemahan Mekanisme Entry & Exit pada `SampleStrategy`**:
   - **Entry terlalu longgar**: Sinyal `enter_long` hanya mengandalkan `crossed_above(rsi, 30)` saat `tema <= bb_middleband` dan `tema > tema.shift(1)` dengan filter `volume > 0`. Tidak ada filter kekuatan tren (`ADX`), konfirmasi EMA jangka menengah/panjang, lonjakan volume (`volume_ratio`), maupun batas spread/volatilitas.
   - **Kontradiksi sinyal `enter_short`**: Menggunakan `crossed_above(rsi, 70)` saat `tema < tema.shift(1)` yang memicu short melawan momentum naik tanpa konfirmasi pembalikan.
   - **Risk/Reward tidak seimbang & posisi menggantung**: `stoploss = -0.10` (-10%) berbanding `minimal_roi` 1%–4% tanpa `trailing_stop` dan tanpa batas waktu posisi stagnan (`custom_exit`), sehingga transaksi profit ditutup terlalu cepat sementara transaksi rugi tertahan lama hingga menyentuh -10%.

---

## 2. Arsitektur Sesudah Refactoring (Two-Tier Hybrid Architecture)

Sesuai prioritas deployment (Streamlit Community Cloud sebagai lingkungan evaluasi awal dan VPS sebagai infrastruktur persisten), sistem dibagi menjadi dua komponen dengan batas tanggung jawab yang tegas:

```
+-----------------------------------------------------------------------------------+
|                        STREAMLIT COMMUNITY CLOUD / LOKAL                          |
|  Entry Point: streamlit_app.py                                                    |
|                                                                                   |
|  +-----------------------------------------------------------------------------+  |
|  | Antarmuka 7 Halaman Bahasa Indonesia (momentum_radar/ui/pages.py)           |  |
|  | 1. Ringkasan              5. Trade History (+ Evaluasi Scalping/Intraday/   |  |
|  | 2. Market Scanner            Swing)                                         |  |
|  | 3. Alert Center           6. Strategy & Risk Settings                       |  |
|  | 4. Open Positions         7. System Health & Logs                           |  |
|  +--------------------------------------+--------------------------------------+  |
|                                         |                                         |
|  +--------------------------------------v--------------------------------------+  |
|  | Lapisan Layanan & Analitik (momentum_radar/)                                |  |
|  | - data_provider.py : Orkestrasi sumber data (API Online vs Historis/Simulasi)| |
|  | - signals.py       : Market Scanner, Skor Kualitas Sinyal, Klasifikasi Gaya |  |
|  | - alerts.py        : Deduplikasi Alert, Cooldown, Alasan Sinyal Ditolak     |  |
|  | - analytics.py     : Kalkulasi P/L Bersih, Win Rate, PF, Expectancy, DD     |  |
|  | - config.py        : Validasi Risiko, Masking Secret, Default DRY-RUN       |  |
|  | - api_client.py    : Klien REST Freqtrade Tahan Gagal (HTTPS, Timeout)      |  |
|  +--------------------------------------+--------------------------------------+  |
+-----------------------------------------|-----------------------------------------+
                                          | HTTPS REST API (/api/v1/*)
                                          | (Opsional saat evaluasi awal;
                                          |  Dashboard tetap berjalan jika Offline)
+-----------------------------------------v-----------------------------------------+
|                     FREQTRADE BACKEND (VPS / SERVER / LOKAL)                      |
|                                                                                   |
|  - Strategi: user_data/strategies/MomentumRadarStrategy.py                        |
|    (Mendukung SCALPING, INTRADAY, SWING + Filter Kualitas + Dynamic Stoploss/Exit)|
|  - Konfigurasi Pengujian : config_examples/config.dryrun.json (dry_run: true)     |
|  - Konfigurasi Produksi  : config_examples/config.live.template.json              |
|  - Persistensi           : SQLite / PostgreSQL (terpisah antara dry-run & live)   |
+-----------------------------------------------------------------------------------+
```

### Pemisahan Status & Entitas Data (`momentum_radar/models.py`)
Untuk mencegah kerancuan antara sinyal dan hasil transaksi, sistem membedakan 5 entitas secara eksplisit:
1. **Confidence AI / Skor Rezim (`ai_confidence`)**: Skor statistik keteraturan tren dan momentum (0–100%). Diberi peringatan eksplisit bahwa angka ini **bukan** probabilitas profit yang terkalibrasi.
2. **Sinyal Strategi (`MarketSignal`)**: Hasil pemindaian indikator (`LONG`, `SHORT`, atau `NO TRADE`) beserta skor kualitas sinyal (0–100), gaya trading (`SCALPING`, `INTRADAY`, `SWING`), level entry, stop-loss, take-profit, dan estimasi R:R bersih setelah biaya.
3. **Alert (`AlertItem`)**: Catatan keputusan atas sinyal dengan status tegas (`BARU`, `KEDALUWARSA`, `DITOLAK`, `DIEKSEKUSI`, `SELESAI`) serta alasan penolakan jika filter kualitas/risiko/cooldown tidak terpenuhi.
4. **Posisi Terbuka & Status Order (`OpenPosition`)**: Posisi yang benar-benar sedang aktif di bot/simulasi beserta `order_status` (`TERISI`, `MENUNGGU LIMIT`, `SEBAGIAN TERISI`), durasi, P/L belum terealisasi, dan status risiko.
5. **Transaksi Tertutup (`ClosedTrade`)**: Transaksi yang sudah keluar (`exit`) beserta perhitungan P/L kotor, estimasi biaya transaksi (entry + exit fee), **P/L bersih setelah biaya**, durasi posisi, alasan exit, dan klasifikasi gaya trading.
