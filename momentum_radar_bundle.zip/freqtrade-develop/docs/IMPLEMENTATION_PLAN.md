# Rencana Implementasi — Refactor Momentum Radar Menjadi Streamlit Dashboard Siap Deploy

## 1. Perbandingan Fitur: Tersedia, Diperbaiki, dan Baru

| Kategori | Komponen / File | Status di Repo Awal | Tindakan Implementasi |
| :--- | :--- | :--- | :--- |
| **Core Bot** | `freqtrade/` | Tersedia & berfungsi | Dipertahankan penuh tanpa mengubah logika inti engine Freqtrade. |
| **REST Client** | `ft_client/freqtrade_client/ft_rest_client.py` | Tersedia (ada bug HTTPS & error handling) | Diperbaiki agar mendukung `https://`, menangani timeout/HTTP error dengan aman, dan memperbaiki `ping()`. |
| **Strategi Trading** | `freqtrade/templates/sample_strategy.py` -> `user_data/strategies/MomentumRadarStrategy.py` | Hanya ada `SampleStrategy` (entry terlalu longgar, exit lambat) | Dibuat `MomentumRadarStrategy.py` yang mendukung `SCALPING`, `INTRADAY`, dan `SWING` dengan filter ADX, EMA multi-periode, volume ratio, spread guard, dynamic ATR stoploss, time-exit stagnan, dan fallback indikator murni Pandas/NumPy. |
| **Layanan & Analitik** | `momentum_radar/` (`config.py`, `models.py`, `api_client.py`, `signals.py`, `alerts.py`, `analytics.py`, `data_provider.py`) | Belum tersedia | Dibuat paket modular untuk pemindaian pasar, deduplikasi alert & cooldown, kalkulasi R:R setelah biaya, evaluasi performa per gaya trading, dan mode evaluasi offline berbasis data historis nyata (`tests/testdata/`). |
| **Dashboard UI** | `streamlit_app.py` & `momentum_radar/ui/` | Belum tersedia | Dibuat aplikasi Streamlit 7 halaman berbahasa Indonesia yang aman dari rerun duplikat dan tetap berjalan lancar saat backend Freqtrade offline. |
| **Konfigurasi & Deployment** | `requirements.txt`, `.streamlit/config.toml`, `.env.example`, `.gitignore`, `config_examples/` | `requirements.txt` tidak kompatibel dengan Streamlit Cloud | Disusun `requirements.txt` yang kompatibel dengan Streamlit Cloud, `requirements-freqtrade.txt` untuk backend VPS, serta dipisahkan `config.dryrun.json` dan `config.live.template.json`. |
| **Pengujian** | `tests/momentum_radar/` | Belum ada tes untuk dashboard & Momentum Radar | Dibuat suite pengujian otomatis mencakup seluruh 14 skenario wajib (import, offline mode, mock API, timeout/error, data kosong, anti-rerun duplicate entry, P/L & metrik, alert gaya trading, validasi risiko, proteksi live order, dan sanitasi secret). |

---

## 2. Tahapan Pelaksanaan Teknis

### Tahap 1 — Perbaikan `FtRestClient` dan Strategi `MomentumRadarStrategy`
1. Memperbaiki `ft_client/freqtrade_client/ft_rest_client.py`:
   - Menambahkan mount `HTTPAdapter` untuk `https://`.
   - Menangani `Timeout`, `RequestException`, dan `ValueError`/`JSONDecodeError` di `_call()` agar tidak memicu crash pada pemanggil.
   - Memperbaiki `ping()` agar mengecek `isinstance(configstatus, dict) and configstatus.get("state") == "running"`.
2. Membuat `user_data/strategies/MomentumRadarStrategy.py`:
   - Mendukung indikator berbasis `talib` (jika tersedia di VPS) maupun perhitungan murni `pandas`/`numpy` (agar dapat dieksekusi langsung di Streamlit Community Cloud tanpa binary C `ta-lib`).
   - Mengimplementasikan aturan terpisah berdasarkan timeframe dan parameter strategi untuk `SCALPING` (`1m`, `5m`), `INTRADAY` (`15m`, `1h`), dan `SWING` (`4h`, `1d`).
   - Menambahkan filter ketat untuk mengatasi masalah *banyak entry namun sedikit tertutup profit*:
     - Konfirmasi tren EMA (`ema_fast > ema_mid > ema_slow` untuk LONG, sebaliknya untuk SHORT).
     - Kekuatan tren `ADX >= 20`.
     - Konfirmasi momentum `RSI` dalam zona sehat (tidak jenuh beli saat entry LONG, tidak jenuh jual saat entry SHORT) + histogram MACD searah.
     - Filter likuiditas `volume_ratio >= 1.15` terhadap rata-rata 20 candle dan estimasi spread/volatilitas wajar.
   - Memperbaiki mekanisme exit:
     - `custom_stoploss` berbasis ATR dinamis dan penguncian profit bertahap (break-even guard setelah profit melampaui 1,2x ATR).
     - `custom_exit` untuk menutup posisi yang stagnan melewati batas durasi gaya trading (`max_holding_minutes`) atau mengalami pembalikan momentum tajam.
     - `confirm_trade_exit` untuk menerapkan cooldown lock otomatis apabila transaksi ditutup rugi akibat stop-loss.

### Tahap 2 — Pembangunan Paket `momentum_radar/`
1. `momentum_radar/models.py`: Struktur data tervalidasi untuk status bot, sinyal scanner, item alert, posisi terbuka, transaksi tertutup, metrik evaluasi per gaya trading, pengaturan risiko, dan kesehatan sistem.
2. `momentum_radar/config.py`: Pengelolaan konfigurasi dengan prioritas `st.secrets` -> environment variables -> file konfigurasi lokal, mode default wajib `DRY-RUN`, validasi batas risiko, dan fungsi sanitasi log (`mask_sensitive_text`, `sanitize_config`).
3. `momentum_radar/api_client.py`: Klien terintegrasi ke REST API Freqtrade dengan pencatatan riwayat koneksi, deteksi data basi (*stale data*), dan pemisahan aksi darurat (`stop_bot`, `stop_new_entries`, `cancel_open_order`, `force_exit_position`).
4. `momentum_radar/signals.py`: Mesin kalkulasi indikator, skor kualitas sinyal (0–100), estimasi biaya & R:R bersih, serta klasifikasi `SCALPING` / `INTRADAY` / `SWING` berbasis timeframe dan struktur volatilitas nyata.
5. `momentum_radar/alerts.py`: Manajer alert dengan deduplikasi berbasis kunci komposit dan *cooldown* per pair, lengkap dengan pencatatan alasan penolakan sinyal.
6. `momentum_radar/analytics.py`: Kalkulator metrik performa (Net P/L setelah biaya, Win Rate, Average Win/Loss, Profit Factor, Expectancy, Max Drawdown, kurva ekuitas) baik secara agregat maupun dirinci per gaya trading (`SCALPING`, `INTRADAY`, `SWING`).
7. `momentum_radar/data_provider.py`: Penyedia data hibrida yang membaca dari Freqtrade REST API saat terhubung, atau mengevaluasi strategi secara nyata terhadap dataset historis `.feather` & hasil backtest di `tests/testdata/` saat backend offline.

### Tahap 3 — Implementasi 7 Halaman Dashboard Streamlit (`streamlit_app.py` & `momentum_radar/ui/`)
1. **Halaman 1 — Ringkasan**: Status koneksi & bot, badge mode `DRY-RUN`/`LIVE` & sumber data, saldo/ekuitas, P/L hari ini & total bersih, metrik performa per periode, kurva ekuitas, serta ringkasan alert & peringatan risiko.
2. **Halaman 2 — Market Scanner**: Tabel dan kartu pemindaian pair dengan harga terakhir, arah tren, momentum, sinyal (`LONG`/`SHORT`/`NO TRADE`), confidence AI (dengan catatan kalibrasi), skor kualitas, alasan pendukung, spread, volume, timeframe, dan filter interaktif.
3. **Halaman 3 — Alert Center**: Daftar alert terstandar dengan gaya trading nyata, TF entry & konfirmasi, harga referensi, SL/TP, R:R bersih setelah biaya, status alert (`BARU`, `KEDALUWARSA`, `DITOLAK`, `DIEKSEKUSI`, `SELESAI`), alasan sinyal ditolak, dan kontrol deduplikasi/cooldown.
4. **Halaman 4 — Open Positions**: Pemantauan posisi terbuka lengkap dengan arah, harga entry vs saat ini, ukuran, P/L nominal & %, SL/TP, durasi, gaya trading, status order, alasan entry awal, dan indikator visual risiko.
5. **Halaman 5 — Trade History**: Riwayat transaksi tertutup dengan filter tanggal, pair, gaya trading, dan hasil transaksi, dilengkapi tabel evaluasi khusus per gaya trading (`SCALPING`, `INTRADAY`, `SWING`) beserta definisi matematis setiap metrik.
6. **Halaman 6 — Strategy & Risk Settings**: Formulir konfigurasi tervalidasi, ringkasan diff perubahan, konfirmasi eksplisit sebelum simpan, pengaman ganda untuk mode `LIVE`, serta panel kontrol darurat yang membedakan *Hentikan Bot*, *Hentikan Entry Baru*, *Batalkan Order Terbuka*, dan *Tutup Posisi Darurat*.
7. **Halaman 7 — System Health & Logs**: Pemeriksaan kesehatan REST API, waktu pembaruan terakhir, status AI/heuristik, status notifikasi, database, riwayat koneksi, indikator data basi, dan log yang telah disanitasi dari kredensial sensitif.

### Tahap 4 — Pengujian, Dokumentasi Deployment, dan Pengemasan
1. Menyiapkan `requirements.txt` (siap Streamlit Cloud) dan `requirements-freqtrade.txt` (untuk VPS backend), `.streamlit/config.toml`, `.env.example`, `.gitignore`, `README.md`, `docs/STREAMLIT_CLOUD_DEPLOYMENT.md`, dan `docs/FREQTRADE_BACKEND_DEPLOYMENT.md`.
2. Menjalankan suite pengujian menyeluruh dan memverifikasi seluruh 12 kriteria selesai.
