import pandas as pd
import talib.abstract as ta


def test_talib_bollingerbands_near_zero_values():
    inputs = pd.DataFrame(
        [
            {"close": 0.000010},
            {"close": 0.000011},
            {"close": 0.000012},
            {"close": 0.000013},
            {"close": 0.000014},
        ]
    )
    bollinger = ta.BBANDS(inputs, timeperiod=2, matype=0)
    assert bollinger["upperband"][3] != bollinger["middleband"][3]
